import stripe
from flask import current_app as app

stripe.api_key = app.config['STRIPE_SECRET_KEY']

def make_payment(payment_data):
    try:
        if payment_data['method'] == 'stripe':
            intent = stripe.PaymentIntent.create(
                amount=payment_data['amount'],
                currency='usd',
                payment_method_types=['card']
            )
            return {"client_secret": intent.client_secret}
        elif payment_data['method'] == 'paypal':
            pass  # Integrate PayPal payment here
        return {"response": "Payment method not supported."}
    except Exception as e:
        return {"error": str(e)}
