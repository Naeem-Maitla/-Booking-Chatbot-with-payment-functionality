from flask import request, jsonify
from app import app
from app.chatbot import handle_message
from app.booking import book_appointment
from app.payment import make_payment

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get('message')
    response = handle_message(user_message)
    return jsonify(response)

@app.route('/book', methods=['POST'])
def book():
    booking_data = request.json
    response = book_appointment(booking_data)
    return jsonify(response)

@app.route('/pay', methods=['POST'])
def pay():
    payment_data = request.json
    response = make_payment(payment_data)
    return jsonify(response)
