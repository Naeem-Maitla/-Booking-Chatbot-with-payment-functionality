def handle_message(message):
    message = message.lower()

    services = ["Haircut", "Beard", "Children's Haircut"]  # Define the services

    if "open" in message:
        return {"response": "We open at 9:00am Monday-Friday and by appointment only on Sundays."}
    elif "fade" in message or "haircut" in message:
        return {"response": "Haircuts typically start at $40.00"}
    elif "beard" in message:
        return {"response": "Beard services start at $25.00"}
    elif "children" in message:
        return {"response": "Our children’s haircut starts at $30.00"}
    elif "hours" in message:
        return {"response": "Monday-Friday 9am-7pm, Saturday 7am-5pm, Sundays by appointment only"}
    elif "book" in message:
        return {"response": "Please select the ‘Book Now’ button to book an appointment.", "services": services}
    elif "walk-in" in message:
        return check_availability()
    elif "payment" in message:
        return {"response": "We accept Square, Zelle, Venmo, Cash App, Cash payments, and crypto."}
    elif "location" in message:
        return {"response": "We’re located at 4001 S Sam Houston Pkwy E unit 131"}
    elif "portfolio" in message or "pictures" in message:
        return {"response": "Yes, check out my portfolio.", "gallery_link": "your_gallery_link_here"}
    elif "address" in message:
        return {"response": "Yes, we’re located at 4001 S Sam Houston Pkwy E unit 131"}
    elif "straight hair" in message:
        return {"response": "Yes, we specialize in all textures of hair"}
    elif "products" in message:
        return {"response": "We use all natural ingredients that will help you with your hair goals."}
    else:
        return {"response": "I'm sorry, I didn't understand that. Can you please rephrase?"}

def check_availability():
    available_times = ["10:00 AM", "11:00 AM", "2:00 PM", "4:00 PM"]
    return {"response": "Yes, we have availability today for walk-ins. To secure your spot we suggest you choose from the following openings.", "times": available_times}