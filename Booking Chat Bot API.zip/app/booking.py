bookings = []

def book_appointment(booking_data):
    bookings.append(booking_data)
    return {"response": "Your appointment has been booked successfully!", "booking": booking_data}
